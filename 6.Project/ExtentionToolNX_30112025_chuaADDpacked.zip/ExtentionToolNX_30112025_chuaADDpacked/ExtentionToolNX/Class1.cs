﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using ExtentionToolNX.UI;
using System.Threading.Tasks;

namespace ExtentionToolNX
{
    public class OpenForm
    {
        public void OpenAutomationManufacturingFile()
        {
            Automation_Manufacturing_File a = new Automation_Manufacturing_File();
            a.Show();
        }

        public void OpenGenQRCode()
        {
            genQRCode b = new genQRCode();
            b.Show();
        }

        public void OpenLicenseAsscessmonitoring()
        {
            license_access_monitoring c = new license_access_monitoring();
            c.Show();
        }
    }
}

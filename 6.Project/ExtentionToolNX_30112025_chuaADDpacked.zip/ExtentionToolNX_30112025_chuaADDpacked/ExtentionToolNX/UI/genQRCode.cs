﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QRCoder;
using ExtentionToolNX.Funcation;
using System.Windows.Forms;


namespace ExtentionToolNX.UI
{
    public partial class genQRCode : Form
    {
        public genQRCode()
        {
            InitializeComponent();
        }

        private void genQRCode_Load(object sender, EventArgs e)
        {

        }

        private void btn_genQRManual_Click(object sender, EventArgs e)
        {
            if(lst_namePart.SelectedItem==null)
            {
                MessageBox.Show("vui lòng chọn một giá trị trong danh sách");
                return;
            }

            string qrText = lst_namePart.SelectedItem.ToString();
            Bitmap prImage = new QRCodeFuncation().GenerateQRCode(qrText); // cách viết nhanh
            pic_QRCode.Image = prImage;

        }

        private void btn_genQRAutomation_Click(object sender, EventArgs e)
        {
            if(lst_namePart.Items.Count == 0)
            {
                MessageBox.Show("danh sách không có dữ liệu");
                return;
            }

            foreach (var item in lst_namePart.Items)
            {
                string qrText = item.ToString();
                Bitmap prImage = new QRCodeFuncation().GenerateQRCode(qrText); // cách viết nhanh
                pic_QRCode.Image = prImage;
                Application.DoEvents(); // Để hình hiển thị rõ từng mã QR nếu muốn

                // Nếu muốn lưu mỗi QR ra file, thêm code sau:
                // qrImage.Save($"QR_{qrText}.png", System.Drawing.Imaging.ImageFormat.Png);
                // hoặc hiển thị lên List/Panel...
            }

            MessageBox.Show("Đã tạo xong QR cho toàn bộ danh sách!");

        }


        

    }
}

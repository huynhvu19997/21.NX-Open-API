﻿namespace ExtentionToolNX.UI
{
    partial class genQRCode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lst_namePart = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_nameAssemblyFile = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_getNamePart = new System.Windows.Forms.Button();
            this.pic_QRCode = new System.Windows.Forms.PictureBox();
            this.btn_genQRManual = new System.Windows.Forms.Button();
            this.btn_genQRAutomation = new System.Windows.Forms.Button();
            this.btn_pastQRToDrawing = new System.Windows.Forms.Button();
            this.btn_exportPDF = new System.Windows.Forms.Button();
            this.gb_getdata = new System.Windows.Forms.GroupBox();
            this.gr_TestQrcode = new System.Windows.Forms.GroupBox();
            this.gb_automation = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            ((System.ComponentModel.ISupportInitialize)(this.pic_QRCode)).BeginInit();
            this.gb_getdata.SuspendLayout();
            this.gr_TestQrcode.SuspendLayout();
            this.gb_automation.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // lst_namePart
            // 
            this.lst_namePart.FormattingEnabled = true;
            this.lst_namePart.Location = new System.Drawing.Point(25, 79);
            this.lst_namePart.Name = "lst_namePart";
            this.lst_namePart.Size = new System.Drawing.Size(301, 303);
            this.lst_namePart.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Danh sách các phần tử Part";
            // 
            // tb_nameAssemblyFile
            // 
            this.tb_nameAssemblyFile.Location = new System.Drawing.Point(107, 16);
            this.tb_nameAssemblyFile.Name = "tb_nameAssemblyFile";
            this.tb_nameAssemblyFile.Size = new System.Drawing.Size(138, 20);
            this.tb_nameAssemblyFile.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Tên Assembly:";
            // 
            // btn_getNamePart
            // 
            this.btn_getNamePart.Location = new System.Drawing.Point(251, 14);
            this.btn_getNamePart.Name = "btn_getNamePart";
            this.btn_getNamePart.Size = new System.Drawing.Size(75, 52);
            this.btn_getNamePart.TabIndex = 4;
            this.btn_getNamePart.Text = "Lấy thành phần ";
            this.btn_getNamePart.UseVisualStyleBackColor = true;
            // 
            // pic_QRCode
            // 
            this.pic_QRCode.Location = new System.Drawing.Point(157, 38);
            this.pic_QRCode.Name = "pic_QRCode";
            this.pic_QRCode.Size = new System.Drawing.Size(166, 140);
            this.pic_QRCode.TabIndex = 5;
            this.pic_QRCode.TabStop = false;
            // 
            // btn_genQRManual
            // 
            this.btn_genQRManual.Location = new System.Drawing.Point(6, 38);
            this.btn_genQRManual.Name = "btn_genQRManual";
            this.btn_genQRManual.Size = new System.Drawing.Size(114, 23);
            this.btn_genQRManual.TabIndex = 6;
            this.btn_genQRManual.Text = "Tạo mã thủ công";
            this.btn_genQRManual.UseVisualStyleBackColor = true;
            this.btn_genQRManual.Click += new System.EventHandler(this.btn_genQRManual_Click);
            // 
            // btn_genQRAutomation
            // 
            this.btn_genQRAutomation.Location = new System.Drawing.Point(6, 72);
            this.btn_genQRAutomation.Name = "btn_genQRAutomation";
            this.btn_genQRAutomation.Size = new System.Drawing.Size(114, 23);
            this.btn_genQRAutomation.TabIndex = 7;
            this.btn_genQRAutomation.Text = "Tạo mã hàng loạt";
            this.btn_genQRAutomation.UseVisualStyleBackColor = true;
            this.btn_genQRAutomation.Click += new System.EventHandler(this.btn_genQRAutomation_Click);
            // 
            // btn_pastQRToDrawing
            // 
            this.btn_pastQRToDrawing.Location = new System.Drawing.Point(32, 49);
            this.btn_pastQRToDrawing.Name = "btn_pastQRToDrawing";
            this.btn_pastQRToDrawing.Size = new System.Drawing.Size(114, 23);
            this.btn_pastQRToDrawing.TabIndex = 8;
            this.btn_pastQRToDrawing.Text = "dán vào drawing";
            this.btn_pastQRToDrawing.UseVisualStyleBackColor = true;
            // 
            // btn_exportPDF
            // 
            this.btn_exportPDF.Location = new System.Drawing.Point(191, 49);
            this.btn_exportPDF.Name = "btn_exportPDF";
            this.btn_exportPDF.Size = new System.Drawing.Size(114, 23);
            this.btn_exportPDF.TabIndex = 9;
            this.btn_exportPDF.Text = "Xuất PDF";
            this.btn_exportPDF.UseVisualStyleBackColor = true;
            // 
            // gb_getdata
            // 
            this.gb_getdata.Controls.Add(this.label1);
            this.gb_getdata.Controls.Add(this.lst_namePart);
            this.gb_getdata.Controls.Add(this.tb_nameAssemblyFile);
            this.gb_getdata.Controls.Add(this.label2);
            this.gb_getdata.Controls.Add(this.btn_getNamePart);
            this.gb_getdata.Location = new System.Drawing.Point(12, 39);
            this.gb_getdata.Name = "gb_getdata";
            this.gb_getdata.Size = new System.Drawing.Size(348, 399);
            this.gb_getdata.TabIndex = 10;
            this.gb_getdata.TabStop = false;
            this.gb_getdata.Text = "xử lí đầu vào";
            // 
            // gr_TestQrcode
            // 
            this.gr_TestQrcode.Controls.Add(this.btn_genQRManual);
            this.gr_TestQrcode.Controls.Add(this.pic_QRCode);
            this.gr_TestQrcode.Controls.Add(this.btn_genQRAutomation);
            this.gr_TestQrcode.Location = new System.Drawing.Point(387, 39);
            this.gr_TestQrcode.Name = "gr_TestQrcode";
            this.gr_TestQrcode.Size = new System.Drawing.Size(355, 217);
            this.gr_TestQrcode.TabIndex = 11;
            this.gr_TestQrcode.TabStop = false;
            this.gr_TestQrcode.Text = "QR code thử nghiệm";
            // 
            // gb_automation
            // 
            this.gb_automation.Controls.Add(this.btn_pastQRToDrawing);
            this.gb_automation.Controls.Add(this.btn_exportPDF);
            this.gb_automation.Location = new System.Drawing.Point(387, 281);
            this.gb_automation.Name = "gb_automation";
            this.gb_automation.Size = new System.Drawing.Size(355, 100);
            this.gb_automation.TabIndex = 12;
            this.gb_automation.TabStop = false;
            this.gb_automation.Text = "Tác vụ tự động";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.progressBar1);
            this.groupBox4.Location = new System.Drawing.Point(387, 387);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(355, 51);
            this.groupBox4.TabIndex = 13;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Tiến trình xử lí";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(20, 19);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(329, 23);
            this.progressBar1.TabIndex = 0;
            // 
            // genQRCode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.gb_automation);
            this.Controls.Add(this.gr_TestQrcode);
            this.Controls.Add(this.gb_getdata);
            this.Name = "genQRCode";
            this.Text = "genQRCode";
            this.Load += new System.EventHandler(this.genQRCode_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pic_QRCode)).EndInit();
            this.gb_getdata.ResumeLayout(false);
            this.gb_getdata.PerformLayout();
            this.gr_TestQrcode.ResumeLayout(false);
            this.gb_automation.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lst_namePart;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_nameAssemblyFile;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_getNamePart;
        private System.Windows.Forms.PictureBox pic_QRCode;
        private System.Windows.Forms.Button btn_genQRManual;
        private System.Windows.Forms.Button btn_genQRAutomation;
        private System.Windows.Forms.Button btn_pastQRToDrawing;
        private System.Windows.Forms.Button btn_exportPDF;
        private System.Windows.Forms.GroupBox gb_getdata;
        private System.Windows.Forms.GroupBox gr_TestQrcode;
        private System.Windows.Forms.GroupBox gb_automation;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ProgressBar progressBar1;
    }
}
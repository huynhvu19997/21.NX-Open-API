﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using NXOpen;
using NXOpen.Drawings;
using NXOpen.Annotations;
using NXOpen.Assemblies;
using NXOpen.UF;
using netDxf;
using netDxf.Entities;
using System.Threading.Tasks;

namespace ExtentionToolNX.Funcation
{
    public class DrawingFuncations
    {
        /// <summary>
        /// Mở file template Drawing NX (ví dụ *.prt chứa Drawing).
        /// </summary>
        /// <param name="templatePath">Đường dẫn tới file template drawing (*.prt)</param>
        /// <returns>Đối tượng Part đã mở hoặc null nếu lỗi</returns>
        public static Part OpenDrawingTemplate(string templatePath)
        {
            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;

            // Mở file drawing template
            BasePart basePart = theSession.Parts.OpenBaseDisplay(templatePath, out loadStatus);
            Part drawingPart = basePart as Part;

            if (drawingPart == null)
            {
                loadStatus.Dispose();
                return null;
            }

            // Đặt làm Work và Display part
            theSession.Parts.SetWork(drawingPart);
            theSession.Parts.SetDisplay(drawingPart, true, true, out loadStatus);

            loadStatus.Dispose();
            return drawingPart;
        }

        /***không có tính năng import png vào drawing **/
        

    }

    public class DrawingTest
    {
        public static void CreateBaseViewOnTemplate(
        string templatePath,
        string partPath,
        string modelViewName,
        double x, double y,
        double scale)
        {
            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;

            // Mở template drawing
            Part drawingPart = theSession.Parts.Open(templatePath, out loadStatus);
            theSession.Parts.SetDisplay(drawingPart, true, true, out loadStatus);

            // Mở part 3D
            Part part3D = theSession.Parts.FindObject(partPath) as Part;
            if (part3D == null)
                part3D = theSession.Parts.Open(partPath, out loadStatus);

            // Lấy sheet đầu tiên và set active
            DrawingSheet sheet = drawingPart.DrawingSheets.ToArray()[0];
            sheet.Open();

            // Tạo base view trên sheet
            BaseViewBuilder baseViewBuilder = drawingPart.DraftingViews.CreateBaseViewBuilder(null);

            // CHỈ GÁN ĐƯỢC NHỮNG THUỘC TÍNH DƯỚI ĐÂY (nếu tồn tại)
            // Nếu không có property Origin, không gán.
            try
            {
                baseViewBuilder.GetType().GetProperty("Origin")?.SetValue(baseViewBuilder, new Point2d(x, y));
            }
            catch { }

            // Nếu không có property Scale hoặc không gán được, bỏ qua.
            try
            {
                baseViewBuilder.GetType().GetProperty("Scale")?.SetValue(baseViewBuilder, scale);
            }
            catch { }

            // Nếu có ModelView thì gán, không thì bỏ qua.
            try
            {
                var modelViewProp = baseViewBuilder.GetType().GetProperty("ModelView");
                if (modelViewProp != null)
                {
                    var modelView = part3D.ModelingViews.FindObject(modelViewName);
                    modelViewProp.SetValue(baseViewBuilder, modelView);
                }
            }
            catch { }

            // Commit tạo view
            NXOpen.NXObject nxObj = baseViewBuilder.Commit();
            DraftingView baseView = nxObj as DraftingView;
            baseViewBuilder.Destroy();

            // Update & save
            Session.UndoMarkId markId = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Add Base View");
            theSession.UpdateManager.DoUpdate(markId);
            drawingPart.Save(BasePart.SaveComponents.True, BasePart.CloseAfterSave.False);

            if (loadStatus != null) loadStatus.Dispose();
        }
    }
}

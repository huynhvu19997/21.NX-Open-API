﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NXOpen;
using NXOpen.UF;
using System.IO;
using NXOpen.Assemblies;
using NXOpen.Drawings;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Diagnostics;

namespace ExtentionToolNX.Funcation
{
    public class GeneralFuncations
    {
        /// <summary>
        /// Kiểm tra phần mềm NX có đang chạy trên máy tính.
        /// </summary>
        public static bool IsNXOpenRunning()
        {
            // "ugraf" là tiến trình mặc định, nhưng NX mới có thể là "nx", "nxbin"
            Process[] nxProcs = Process.GetProcessesByName("ugraf");
            if (nxProcs.Length == 0)
                nxProcs = Process.GetProcessesByName("nx");
            if (nxProcs.Length == 0)
                nxProcs = Process.GetProcessesByName("nxbin");
            return nxProcs.Length > 0;
        }

        /// <summary>
        /// Mở phần mềm NX với giao diện hiện ra (normal).
        /// Trả về đối tượng Process.
        /// nxExePath là đường dẫn đến file chạy của NX (ví dụ "C:\\Program Files\\Siemens\\NX2401\\NXBIN\\ugraf.exe").
        /// </summary>
        public Process OpenNXVisible(string nxExePath)
        {
            var startInfo = new ProcessStartInfo(nxExePath)
            {
                WindowStyle = ProcessWindowStyle.Normal,
                CreateNoWindow = false
            };
            return Process.Start(startInfo);
        }


        /// <summary>
        /// Mở phần mềm NX ở chế độ ẩn (run hidden).
        /// Trả về đối tượng Process.
        /// </summary>
        public Process OpenNXHidden(string nxExePath)
        {
            var startInfo = new ProcessStartInfo(nxExePath)
            {
                WindowStyle = ProcessWindowStyle.Hidden,
                CreateNoWindow = true
            };
            return Process.Start(startInfo);
        }

        /// <summary>
        /// Đóng tất cả tiến trình NX đang chạy (ugraf, nx, nxbin).
        /// </summary>
        public static void CloseAllNX()
        {
            string[] nxProcessNames = { "ugraf", "nx", "nxbin" };
            foreach (string procName in nxProcessNames)
            {
                var nxProcs = Process.GetProcessesByName(procName);
                foreach (var proc in nxProcs)
                {
                    try
                    {
                        // Thử đóng nhẹ nhàng
                        proc.CloseMainWindow();
                        if (!proc.WaitForExit(2000)) // Chờ 2 giây
                        {
                            // Nếu không được, kill cứng
                            proc.Kill();
                        }
                    }
                    catch
                    {
                        // Bỏ qua các lỗi (ví dụ không có quyền)
                    }
                }
            }
        }


    }

    public class OpenParrt
    {
        public static Part OpenPartDisplay(string partPath)
        {
            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;
            Part part = theSession.Parts.Open(partPath, out loadStatus);

            // Đặt làm display part (hiện lên giao diện NX)
            theSession.Parts.SetDisplay(part, true, true, out loadStatus);

            loadStatus.Dispose();
            return part;
        }

        public static Part OpenPartHidden(string partPath)
        {
            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;

            // OpenBase chỉ thêm part vào session, không hiện lên giao diện
            BasePart basePart = theSession.Parts.OpenBase(partPath, out loadStatus);

            Part part = basePart as Part;
            loadStatus.Dispose();
            return part;
        }
    }

    public class OpenAssembly
    {
        public static Part OpenAssemblyDisplay(string asmPath)
        {
            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;
            Part asmPart = theSession.Parts.Open(asmPath, out loadStatus);

            // Đặt làm display part (hiện trên giao diện NX)
            theSession.Parts.SetDisplay(asmPart, true, true, out loadStatus);

            loadStatus.Dispose();
            return asmPart;
        }

        public static Part OpenAssemblyHidden(string asmPath)
        {
            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;

            // OpenBase chỉ thêm vào session, không set display
            BasePart baseAsm = theSession.Parts.OpenBase(asmPath, out loadStatus);
            Part asmPart = baseAsm as Part;

            loadStatus.Dispose();
            return asmPart;
        }
    }

    public class CreatePlatform
    {
        /// <summary>
        /// Tạo mới file Part, Assembly, hoặc Drawing với chuẩn ISO, đơn vị mm.
        /// </summary>
        /// <param name="fullPath">Đường dẫn lưu file mới, bao gồm cả tên file .prt</param>
        /// <param name="type">Loại file: "Part", "Assembly", hoặc "Drawing"</param>
        public static void CreateNXFileISOmm(string fullPath, string type)
        {
            Session theSession = Session.GetSession();
            UFSession ufs = UFSession.GetUFSession();

            // Lựa chọn template phù hợp
            string template = "";
            switch (type.ToLower())
            {
                case "part":
                    template = @"C:\Program Files\Siemens\NX2410\templates\model-iso-mm.prt";
                    break;
                case "assembly":
                    template = @"C:\Program Files\Siemens\NX2410\templates\assembly-iso-mm.prt";
                    break;
                case "drawing":
                    template = @"C:\Program Files\Siemens\NX2410\templates\drawing-iso-mm.prt";
                    break;
                default:
                    throw new ArgumentException("Type phải là: 'part', 'assembly', hoặc 'drawing'");
            }

            // 1. Tạo file mới từ template
            int units = 1; // 1 = mm, 2 = inch
            Tag partTag;
            ufs.Part.New(fullPath, units, out partTag);

            // 2. Mở part vừa tạo
            Part newPart = (Part)Session.GetSession().Parts.FindObject(fullPath);

            // 3. (Tuỳ chọn) Áp dụng template cho drawing nếu là drawing
            // NXOpen không hỗ trợ clone trực tiếp từ template qua API public, nhưng bạn có thể copy các thành phần
            // hoặc tạo mới từ template bằng journal/macro nếu cần

            // 4. Lưu part
            newPart.Save(BasePart.SaveComponents.True, BasePart.CloseAfterSave.False);
        }

        //cách dùng
        //CreateNXFileISOmm(@"D:\DATA\model1.prt", "part");
        //CreateNXFileISOmm(@"D:\DATA\assy1.prt", "assembly");
        //CreateNXFileISOmm(@"D:\DATA\drawing1.prt", "drawing");
    }

    public class SetView
    {
        /// <summary>
        /// Hướng nhìn chính diện (Front)
        /// </summary>
        public static void ViewFront()
        {
            Session theSession = Session.GetSession();
            theSession.Parts.Work.ModelingViews.WorkView.Orient(NXOpen.View.Canned.Front, NXOpen.View.ScaleAdjustment.Fit);
        }

        /// <summary>
        /// Hướng nhìn từ trên xuống (Top)
        /// </summary>
        public static void ViewTop()
        {
            Session theSession = Session.GetSession();
            theSession.Parts.Work.ModelingViews.WorkView.Orient(NXOpen.View.Canned.Top, NXOpen.View.ScaleAdjustment.Fit);
        }

        /// <summary>
        /// Hướng nhìn bên phải (Right)
        /// </summary>
        public static void ViewRight()
        {
            Session theSession = Session.GetSession();
            theSession.Parts.Work.ModelingViews.WorkView.Orient(NXOpen.View.Canned.Right, NXOpen.View.ScaleAdjustment.Fit);
        }

        /// <summary>
        /// Hướng nhìn isometric
        /// </summary>
        public static void ViewIsometric()
        {
            Session theSession = Session.GetSession();
            theSession.Parts.Work.ModelingViews.WorkView.Orient(NXOpen.View.Canned.Isometric, NXOpen.View.ScaleAdjustment.Fit);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NXOpen;
using NXOpenUI;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace ExtentionToolNX.Funcation
{
    public class PartFuncations
    {
        /// <summary>
        /// Mở part NX, thay đổi parameter theo tên, update mô hình.
        /// </summary>
        /// <param name="partPath">Đường dẫn file part (*.prt)</param>
        /// <param name="paramName">Tên parameter (Expression)</param>
        /// <param name="newValue">Giá trị mới cho parameter</param>
        /// <returns>Part đã cập nhật, hoặc null nếu lỗi</returns>
        public static Part OpenChangeParamUpdate(string partPath, string paramName, double newValue)
        {
            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;

            // Mở part
            BasePart basePart = theSession.Parts.OpenBaseDisplay(partPath, out loadStatus);
            Part workPart = basePart as Part;
            if (workPart == null)
            {
                loadStatus.Dispose();
                return null;
            }

            // Set Work và Display
            theSession.Parts.SetWork(workPart);
            theSession.Parts.SetDisplay(workPart, true, true, out loadStatus);

            // Tìm parameter theo tên
            Expression targetExp = null;
            foreach (Expression exp in workPart.Expressions)
            {
                if (exp.Name == paramName)
                {
                    targetExp = exp;
                    break;
                }
            }
            if (targetExp == null)
            {
                loadStatus.Dispose();
                return null;
            }

            // Thay đổi giá trị
            targetExp.Value = newValue;

            // Đặt undo mark và update mô hình
            Session.UndoMarkId markId = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Update Model");
            theSession.UpdateManager.DoUpdate(markId);

            loadStatus.Dispose();
            return workPart;
        }


        /* Cách sử dụng
            string myPartPath = @"D:\NX_Projects\sample_part.prt";
            string parameterName = "p1";
            double newValue = 100.0;

            var part = NxPartHelper.OpenChangeParamUpdate(myPartPath, parameterName, newValue);

            if (part == null)
                Console.WriteLine("Không tìm thấy parameter hoặc lỗi khi mở part.");
            else
                Console.WriteLine("Đã cập nhật thành công.");

         */

        //********************************Cập nhật nhiều giá trị tham số******************************//

        public class PartParameterUpdate
        {
            public string PartPath { get; set; }
            public Dictionary<string, double> Parameters { get; set; } = new Dictionary<string, double>();
        }

        /// <summary>
        /// Mở nhiều part, đổi nhiều parameter và update tự động.
        /// </summary>
        /// <param name="partUpdates">Danh sách các part và các parameter cần đổi</param>
        /// <returns>Danh sách Part đã update (bỏ qua part lỗi hoặc không có parameter)</returns>
        public static List<Part> OpenChangeMultiParamUpdate(List<PartParameterUpdate> partUpdates)
        {
            Session theSession = Session.GetSession();
            List<Part> updatedParts = new List<Part>();

            foreach (var partUpdate in partUpdates)
            {
                PartLoadStatus loadStatus;
                BasePart basePart = theSession.Parts.OpenBaseDisplay(partUpdate.PartPath, out loadStatus);
                Part workPart = basePart as Part;
                if (workPart == null)
                {
                    loadStatus.Dispose();
                    continue; // Không mở được part
                }

                theSession.Parts.SetWork(workPart);
                theSession.Parts.SetDisplay(workPart, true, true, out loadStatus);

                bool foundAnyParameter = false;
                foreach (var kv in partUpdate.Parameters)
                {
                    string paramName = kv.Key;
                    double newValue = kv.Value;

                    Expression targetExp = null;
                    foreach (Expression exp in workPart.Expressions)
                    {
                        if (exp.Name == paramName)
                        {
                            targetExp = exp;
                            break;
                        }
                    }

                    if (targetExp != null)
                    {
                        targetExp.Value = newValue;
                        foundAnyParameter = true;
                    }
                    // Nếu không tìm thấy parameter, có thể log hoặc bỏ qua
                }

                if (foundAnyParameter)
                {
                    // Đặt undo mark và update
                    Session.UndoMarkId markId = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Update Model");
                    theSession.UpdateManager.DoUpdate(markId);
                    updatedParts.Add(workPart);
                }

                loadStatus.Dispose();
            }

            return updatedParts;
        }

        /*Cách sử dụng 
         *  var partUpdates = new List<NxPartHelper.PartParameterUpdate>
            {
                new NxPartHelper.PartParameterUpdate
                {
                    PartPath = @"D:\NX_Projects\part1.prt",
                    Parameters = new Dictionary<string, double>
                    {
                        {"p1", 50.0 },
                        {"p2", 27.5 }
                    }
                },
                new NxPartHelper.PartParameterUpdate
                {
                    PartPath = @"D:\NX_Projects\part2.prt",
                    Parameters = new Dictionary<string, double>
                    {
                        {"D", 150.0 }
                    }
                }
            };

            var updatedParts = NxPartHelper.OpenChangeMultiParamUpdate(partUpdates);

            if (updatedParts.Count == 0)
                Console.WriteLine("Không cập nhật được part nào.");
            else
                Console.WriteLine($"Cập nhật thành công {updatedParts.Count} part.");

         */

        /**************************Thay đổi nhiều giá trị tham số nhaaph vào *******************/

        /// <summary>
        /// Cập nhật nhiều tham số (expression) của một part NX theo tên.
        /// Nếu có lỗi sẽ throw Exception ra ngoài.
        /// </summary>

        public static void UpdateParameters(string partName, List<string> parameterNames, List<string> parameterValues)
        {
            if (parameterNames.Count != parameterValues.Count)
                throw new ArgumentException("Số lượng tên tham số và giá trị không khớp.");

            // Lấy session NX hiện tại
            Session theSession = Session.GetSession();

            // Mở part (hoặc lấy part đang mở)
            Part workPart = null;

            // Nếu part đã mở, lấy từ session
            if (theSession.Parts.FindObject(partName) != null)
            {
                workPart = (Part)theSession.Parts.FindObject(partName);
            }
            else
            {
                PartLoadStatus loadStatus;
                workPart = theSession.Parts.Open(partName, out loadStatus);
                // Nếu muốn, có thể kiểm tra loadStatus sau khi mở part
            }

            // Cập nhật từng tham số
            for (int i = 0; i < parameterNames.Count; i++)
            {
                string paraName = parameterNames[i];
                string paraValue = parameterValues[i];

                // Tìm expression theo tên
                Expression exp = null;
                foreach (Expression e in workPart.Expressions)
                {
                    if (e.Name == paraName)
                    {
                        exp = e;
                        break;
                    }
                }

                if (exp != null)
                {
                    exp.RightHandSide = paraValue;
                }
                else
                {
                    throw new Exception($"Không tìm thấy tham số tên: {paraName}");
                }
            }

            workPart.Save(BasePart.SaveComponents.True, BasePart.CloseAfterSave.False);
            // Không cần return gì cả
        }

        ////Cách sử dụng 
        //using System.Collections.Generic;

        //// Danh sách tên tham số và giá trị mới
        // var names = new List<string> { "D1", "LENGTH", "WIDTH" };
        //    var values = new List<string> { "50", "100", "25" };

        //// Đường dẫn tới file part NX muốn cập nhật
        //string partPath = @"C:\NXParts\demo.prt";


        /************************************************************************/
        /// <summary>
        /// Mở part NX, thay đổi parameter theo tên, update mô hình.
        /// Hỗ trợ cả User Parameter và Model Parameter (dựa trên tên biến).
        /// </summary>
        public void OpenChangeParamUpdate_UserOrModelParameter(string partPath, string paramName, double newValue)
        {
            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;

            // Mở part
            BasePart basePart = theSession.Parts.OpenBaseDisplay(partPath, out loadStatus);
            Part workPart = basePart as Part;
            if (workPart == null)
            {
                loadStatus.Dispose();
                throw new Exception($"Không mở được part: {partPath}");
            }

            // Set Work và Display
            theSession.Parts.SetWork(workPart);
            theSession.Parts.SetDisplay(workPart, true, true, out loadStatus);

            // Tìm parameter theo tên
            Expression targetExp = null;
            foreach (Expression exp in workPart.Expressions)
            {
                if (exp.Name == paramName)
                {
                    targetExp = exp;
                    break;
                }
            }

            if (targetExp == null)
            {
                loadStatus.Dispose();
                throw new Exception($"Không tìm thấy tham số tên: {paramName}");
            }

            // Phân biệt: User Parameter nếu KHÔNG phải dạng p1, p2, p3...
            bool isUserParameter = !System.Text.RegularExpressions.Regex.IsMatch(targetExp.Name, @"^p\d+$");

            try
            {
                targetExp.Value = newValue;
            }
            catch (Exception ex)
            {
                loadStatus.Dispose();
                throw new Exception(
                    isUserParameter ?
                    $"Không thể cập nhật User Parameter '{paramName}': {ex.Message}" :
                    $"Không thể cập nhật Model Parameter '{paramName}': {ex.Message}"
                );
            }

            // Đặt undo mark và update mô hình
            Session.UndoMarkId markId = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Update Model");
            theSession.UpdateManager.DoUpdate(markId);

            loadStatus.Dispose();
        }


        /// <summary>
        /// Cập nhật nhiều tham số (expression) của một part NX theo tên.
        /// Hỗ trợ cả User Parameter và Model Parameter (dựa trên tên biến).
        /// Nếu có lỗi sẽ throw Exception ra ngoài.
        /// </summary>
        public static void UpdateParameters_UserOrModelParameter(string partName, List<string> parameterNames, List<string> parameterValues)
        {
            if (parameterNames.Count != parameterValues.Count)
                throw new ArgumentException("Số lượng tên tham số và giá trị không khớp.");

            Session theSession = Session.GetSession();
            Part workPart = null;

            // Nếu part đã mở, lấy từ session
            if (theSession.Parts.FindObject(partName) != null)
            {
                workPart = (Part)theSession.Parts.FindObject(partName);
            }
            else
            {
                PartLoadStatus loadStatus;
                workPart = theSession.Parts.Open(partName, out loadStatus);
            }

            for (int i = 0; i < parameterNames.Count; i++)
            {
                string paraName = parameterNames[i];
                string paraValue = parameterValues[i];

                // Tìm expression theo tên
                Expression exp = null;
                foreach (Expression e in workPart.Expressions)
                {
                    if (e.Name == paraName)
                    {
                        exp = e;
                        break;
                    }
                }

                if (exp != null)
                {
                    bool isUserParameter = !System.Text.RegularExpressions.Regex.IsMatch(exp.Name, @"^p\d+$");
                    try
                    {
                        exp.RightHandSide = paraValue;
                    }
                    catch (Exception ex)
                    {
                        throw new Exception(
                            isUserParameter ?
                            $"Không thể cập nhật User Parameter '{paraName}': {ex.Message}" :
                            $"Không thể cập nhật Model Parameter '{paraName}': {ex.Message}"
                        );
                    }
                }
                else
                {
                    throw new Exception($"Không tìm thấy tham số tên: {paraName}");
                }
            }

            // Cập nhật mô hình
            Session.UndoMarkId markId = Session.GetSession().SetUndoMark(Session.MarkVisibility.Visible, "Update Model");
            Session.GetSession().UpdateManager.DoUpdate(markId);

            workPart.Save(BasePart.SaveComponents.True, BasePart.CloseAfterSave.False);
        }


        //Cách sử dụng
        // Cho 1 parameter
        //OpenChangeParamUpdate(@"C:\NXParts\demo.prt", "LENGTH", 120);

        //// Cho nhiều parameter
        //var names = new List<string> { "LENGTH", "WIDTH" };
        //var values = new List<string> { "120", "50" };
        //UpdateParameters(@"C:\NXParts\demo.prt", names, values);


        /************************************************************/

        /// <summary>
        /// Lấy danh sách tên các feature có trong Part.
        /// </summary>
        /// <param name="workPart">Đối tượng Part đang mở.</param>
        /// <returns>List tên các feature.</returns>
        public static List<string> ListAllFeatures(Part workPart)
        {
            var results = new List<string>();

            NXOpen.Features.Feature[] features = workPart.Features.ToArray();

            foreach (var feature in features)
            {
                string name = feature.Name;
                string type = feature.FeatureType; // Sửa ở đây

                results.Add($"{name} ({type})");
            }

            return results;
        }


        /// <summary>
        /// Lấy danh sách tên và loại các feature từ tên part.
        /// </summary>
        /// <param name="partName">Tên hoặc đường dẫn đầy đủ tới part.</param>
        /// <returns>Danh sách các feature (tên và loại).</returns>
        public static List<string> ListAllFeatures(string partName)
        {
            var results = new List<string>();
            Session theSession = Session.GetSession();
            Part workPart = null;

            // Kiểm tra part đã mở chưa, nếu chưa thì mở
            if (theSession.Parts.FindObject(partName) != null)
            {
                workPart = (Part)theSession.Parts.FindObject(partName);
            }
            else
            {
                PartLoadStatus loadStatus;
                workPart = theSession.Parts.Open(partName, out loadStatus);
            }

            NXOpen.Features.Feature[] features = workPart.Features.ToArray();

            foreach (var feature in features)
            {
                string name = feature.Name;
                string type = feature.FeatureType;
                results.Add($"{name} ({type})");
            }

            return results;
        }
        //Cách sử dụng 
        //string partPath = @"C:\NXParts\demo.prt"; // Hoặc chỉ tên nếu part đã mở
        //List<string> features = NxFeatureLister.ListAllFeatures(partPath);

        //foreach (var f in features)
        //{
        //    Console.WriteLine(f);
        //    // hoặc MessageBox.Show(f);
        //}

    /********************************************/
    /// <summary>
    /// Suppress hoặc Unsuppress một feature theo tên part và tên feature.
    /// mode = 1: suppress, mode = 2: unsuppress
    /// </summary>
    public static void SetFeatureSuppression(string partName, string featureName, int mode)
        {
            Session theSession = Session.GetSession();
            Part workPart = null;

            // Nếu part đã mở, lấy ra; nếu chưa, mở từ file
            if (theSession.Parts.FindObject(partName) != null)
            {
                workPart = (Part)theSession.Parts.FindObject(partName);
            }
            else
            {
                PartLoadStatus loadStatus;
                workPart = theSession.Parts.Open(partName, out loadStatus);
            }

            var features = workPart.Features.ToArray();

            foreach (var feature in features)
            {
                if (feature.Name == featureName)
                {
                    if (mode == 1)
                        feature.Suppress();
                    else if (mode == 2)
                        feature.Unsuppress();
                    else
                        throw new ArgumentException("Mode phải là 1 (suppress) hoặc 2 (unsuppress)");
                    return;
                }
            }

            throw new Exception($"Không tìm thấy feature tên: {featureName} trong part {partName}");
        }


        /// <summary>
        /// Suppress feature theo tên part và tên feature.
        /// </summary>
        public static void SuppressFeature(string partName, string featureName)
        {
            Session theSession = Session.GetSession();
            Part workPart = null;
            if (theSession.Parts.FindObject(partName) != null)
            {
                workPart = (Part)theSession.Parts.FindObject(partName);
            }
            else
            {
                PartLoadStatus loadStatus;
                workPart = theSession.Parts.Open(partName, out loadStatus);
            }

            var features = workPart.Features.ToArray();
            foreach (var feature in features)
            {
                if (feature.Name == featureName)
                {
                    feature.Suppress();
                    return;
                }
            }
            throw new Exception($"Không tìm thấy feature tên: {featureName} trong part {partName}");
        }

        /// <summary>
        /// Unsuppress feature theo tên part và tên feature.
        /// </summary>
        public static void UnsuppressFeature(string partName, string featureName)
        {
            Session theSession = Session.GetSession();
            Part workPart = null;
            if (theSession.Parts.FindObject(partName) != null)
            {
                workPart = (Part)theSession.Parts.FindObject(partName);
            }
            else
            {
                PartLoadStatus loadStatus;
                workPart = theSession.Parts.Open(partName, out loadStatus);
            }

            var features = workPart.Features.ToArray();
            foreach (var feature in features)
            {
                if (feature.Name == featureName)
                {
                    feature.Unsuppress();
                    return;
                }
            }
            throw new Exception($"Không tìm thấy feature tên: {featureName} trong part {partName}");
        }

        //Cách sử dụng
        //NxFeatureUtils.SetFeatureSuppression(@"C:\NXParts\demo.prt", "EXTRUDE(2)", 1); // Suppress
        //NxFeatureUtils.SetFeatureSuppression(@"C:\NXParts\demo.prt", "EXTRUDE(2)", 2); // Unsuppress

        //// Hoặc gọi hàm riêng biệt:
        //NxFeatureUtils.SuppressFeature(@"C:\NXParts\demo.prt", "EXTRUDE(2)");
        //NxFeatureUtils.UnsuppressFeature(@"C:\NXParts\demo.prt", "EXTRUDE(2)");

        /***************************************************************************************/

        /// <summary>
        /// Suppress hoặc Unsuppress một feature theo tên.
        /// </summary>
        /// <param name="workPart">Part đang mở.</param>
        /// <param name="featureName">Tên feature.</param>
        /// <param name="mode">1: suppress, 2: unsuppress.</param>
        public static void SetFeatureSuppression(Part workPart, string featureName, int mode)
        {
            var features = workPart.Features.ToArray();

            foreach (var feature in features)
            {
                if (feature.Name == featureName)
                {
                    if (mode == 1)
                        feature.Suppress();
                    else if (mode == 2)
                        feature.Unsuppress();
                    else
                        throw new ArgumentException("Mode phải là 1 (suppress) hoặc 2 (unsuppress)");

                    return;
                }
            }

            throw new Exception($"Không tìm thấy feature tên: {featureName}");
        }


        /// <summary>
        /// Suppress feature theo tên.
        /// </summary>
        public static void SuppressFeature(Part workPart, string featureName)
        {
            var features = workPart.Features.ToArray();
            foreach (var feature in features)
            {
                if (feature.Name == featureName)
                {
                    feature.Suppress();
                    return;
                }
            }
            throw new Exception($"Không tìm thấy feature tên: {featureName}");
        }

        /// <summary>
        /// Unsuppress feature theo tên.
        /// </summary>
        public static void UnsuppressFeature(Part workPart, string featureName)
        {
            var features = workPart.Features.ToArray();
            foreach (var feature in features)
            {
                if (feature.Name == featureName)
                {
                    feature.Unsuppress();
                    return;
                }
            }
            throw new Exception($"Không tìm thấy feature tên: {featureName}");
        }

        //Cách sử dụng

        //Session theSession = Session.GetSession();
        //Part workPart = theSession.Parts.Work;

        //// Suppress
        //NxFeatureUtils.SetFeatureSuppression(workPart, "EXTRUDE(2)", 1);
        //// hoặc
        //NxFeatureUtils.SuppressFeature(workPart, "EXTRUDE(2)");

        //// Unsuppress
        //NxFeatureUtils.SetFeatureSuppression(workPart, "EXTRUDE(2)", 2);
        //// hoặc
        //NxFeatureUtils.UnsuppressFeature(workPart, "EXTRUDE(2)");

        /***********************************************/

        /// <summary>
        /// Đổi màu sắc cho toàn bộ part.
        /// </summary>
        /// <param name="partName">Tên (hoặc đường dẫn) part.</param>
        /// <param name="colorIndex">Mã màu NX (1~216).</param>
        public static void SetPartColor(string partName, int colorIndex)
        {
            Session theSession = Session.GetSession();
            Part workPart = null;
            if (theSession.Parts.FindObject(partName) != null)
            {
                workPart = (Part)theSession.Parts.FindObject(partName);
            }
            else
            {
                PartLoadStatus loadStatus;
                workPart = theSession.Parts.Open(partName, out loadStatus);
            }

            // Đổi màu cho tất cả các body trong part
            foreach (Body body in workPart.Bodies)
            {
                if (body != null)
                    body.Color = colorIndex;
            }
            // Nếu muốn đổi màu luôn cho part display (hiện thị), thì dùng:
            // workPart.Display.ModifiableColor = colorIndex; // Không bắt buộc, tùy nhu cầu
        }

        // cách sử dụng
        //// Đổi màu part sang màu 186 (màu xanh dương trong NX)
        //NxPartAppearance.SetPartColor(@"C:\NXParts\demo.prt", 186);
        /*****************************************************/

        /// <summary>
        /// Đổi vật liệu cho part.
        /// </summary>
        /// <param name="partName">Tên (hoặc đường dẫn) part.</param>
        /// <param name="materialName">Tên vật liệu (ví dụ: "Steel", "Aluminum", ...).</param>
        public static void SetPartMaterialByAttribute(string partName, string materialName)
        {

            Session theSession = Session.GetSession();
            Part workPart;
            if (theSession.Parts.FindObject(partName) != null)
            {
                workPart = (Part)theSession.Parts.FindObject(partName);
            }
            else
            {
                PartLoadStatus loadStatus;
                workPart = theSession.Parts.Open(partName, out loadStatus);
            }

            // Đặt user attribute "Material" cho tất cả body
            foreach (Body body in workPart.Bodies)
            {
                body.SetUserAttribute(
                    "Material",           // Tên thuộc tính
                    -1,                   // Index
                    materialName,         // Giá trị chuỗi tên vật liệu
                    NXOpen.Update.Option.Now // Cập nhật ngay
                );
            }

            // Nếu muốn đặt cho Part luôn:
            // workPart.SetUserAttribute("Material", -1, materialName, NXOpen.Update.Option.Now);
        }
    }
}

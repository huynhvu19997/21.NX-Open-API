﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;
using ExtentionToolNX.Funcation;
using ExtentionToolNX.UI;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace ExtentionToolNX.Funcation
{
    public class FileFuncation
    {
        public string OpenDialog(string filter = "All files|*.*|NX Part Files (*.prt)|*.prt")
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = filter;
                if (ofd.ShowDialog() == DialogResult.OK)
                    return ofd.FileName;
                else
                    return null;
            }
        }

        public string SaveFileDialog(string filter = "Tất cả file|*.*", string defaultFileName = "")
        {
            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = filter;
                sfd.FileName = defaultFileName;
                if (sfd.ShowDialog() == DialogResult.OK)
                    return sfd.FileName;
                else
                    return null;
            }
        }

        /// <summary>
        /// Lưu file với đường dẫn cố định
        /// </summary>
        public static bool SaveFileFixedPath(string filePath, byte[] data)
        {
            try
            {
                File.WriteAllBytes(filePath, data);
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Mở file với đường dẫn cố định, trả về dữ liệu dạng byte[]
        /// </summary>
        public static byte[] OpenFileFixedPath(string filePath)
        {
            if (File.Exists(filePath))
                return File.ReadAllBytes(filePath);
            else
                return null;
        }

        /// <summary>
        /// Kiểm tra folder có tồn tại không, nếu chưa thì tạo mới
        /// </summary>
        public static bool CheckAndCreateFolder(string folderPath)
        {
            if (!Directory.Exists(folderPath))
            {
                try
                {
                    Directory.CreateDirectory(folderPath);
                    return true;
                }
                catch
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Kiểm tra trong folder đã có file tên như nhập chưa
        /// </summary>
        public static bool IsFileExists(string folderPath, string fileName)
        {
            string filePath = Path.Combine(folderPath, fileName);
            return File.Exists(filePath);
        }


        public void SelectForder(TextBox txtFolder)
        {
            using (FolderBrowserDialog fbd = new FolderBrowserDialog())
            {
                fbd.Description = "Chọn thư mục lưu file";
                if (fbd.ShowDialog() == DialogResult.OK)
                {
                    txtFolder.Text = fbd.SelectedPath;
                }
            }
        }

        public string BuildFullFilePath(TextBox txtFolder, TextBox txtFile)
        {
            string folderPath = txtFolder.Text.Trim();
            string fileName = txtFile.Text.Trim();

            if (string.IsNullOrEmpty(folderPath) || string.IsNullOrEmpty(fileName))
                return null;

            return System.IO.Path.Combine(folderPath, fileName);
        }

    }
}

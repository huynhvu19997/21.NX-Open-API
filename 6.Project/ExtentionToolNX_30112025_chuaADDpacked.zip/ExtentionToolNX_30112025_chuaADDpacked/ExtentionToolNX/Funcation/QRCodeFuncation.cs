﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using QRCoder;
using netDxf;
using netDxf.Entities;
using System.Threading.Tasks;

namespace ExtentionToolNX.Funcation
{
    public class QRCodeFuncation
    {
        public Bitmap GenerateQRCode(string qrText)
        {
            QRCodeGenerator qrgen = new QRCodeGenerator();
            QRCodeData qrData = qrgen.CreateQrCode(qrText, QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrData);
            return qrCode.GetGraphic(7);
        }

        public void SaveQRCodeToPng(string qrText, string filePath)
        {
            var qrGen = new QRCodeFuncation();
            Bitmap bmp = qrGen.GenerateQRCode(qrText);
            bmp.Save(filePath, System.Drawing.Imaging.ImageFormat.Png);
        }


        public byte[] GenerateQRCodePngBytes(string qrText)
        {
            QRCodeGenerator qrgen = new QRCodeGenerator();
            QRCodeData qrData = qrgen.CreateQrCode(qrText, QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrData);
            using (Bitmap bmp = qrCode.GetGraphic(7))
            using (var stream = new System.IO.MemoryStream())
            {
                bmp.Save(stream, System.Drawing.Imaging.ImageFormat.Png);
                return stream.ToArray();
            }
        }

        public void GenerateQRCodeDxf(string qrText, string dxfPath, double size = 1.0, double gap = 0.0)
        {
            // 1. Sinh bitmap QR
            Bitmap bmp = GenerateQRCode(qrText);

            // 2. Tạo file DXF
            var dxf = new DxfDocument();

            // 3. Quét từng pixel; nếu là đen thì vẽ 1 hình vuông
            for (int x = 0; x < bmp.Width; x++)
            {
                for (int y = 0; y < bmp.Height; y++)
                {
                    Color pixel = bmp.GetPixel(x, y);
                    if (pixel.R < 128 && pixel.G < 128 && pixel.B < 128)
                    {
                        // Gốc tọa độ vẽ (có thể điều chỉnh nếu muốn)
                        double px = x * (size + gap);
                        double py = -y * (size + gap); // âm y để QR đứng thẳng trong DXF

                        // 4 điểm của hình vuông
                        var pts = new List<netDxf.Vector2>
                {
                    new netDxf.Vector2(px, py),
                    new netDxf.Vector2(px + size, py),
                    new netDxf.Vector2(px + size, py + size),
                    new netDxf.Vector2(px, py + size),
                    new netDxf.Vector2(px, py) // Đóng kín
                };

                        // Tạo Polyline đóng kín (hình vuông)
                        var square = new LwPolyline(pts, true);
                        dxf.AddEntity(square);
                    }
                }
            }

            // 4. Lưu DXF
            dxf.Save(dxfPath);
            bmp.Dispose();
        }

    }
}

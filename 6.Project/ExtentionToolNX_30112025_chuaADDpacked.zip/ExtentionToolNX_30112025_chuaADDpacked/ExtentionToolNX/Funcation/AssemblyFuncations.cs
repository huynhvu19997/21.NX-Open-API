﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using NXOpen;
using NXOpen.Assemblies;
using System.Threading.Tasks;
using NXOpen.Positioning;

namespace ExtentionToolNX.Funcation
{
    class AssemblyFuncations
    {
        public void ListAllComponents(string assemblyFilePath)
        {
            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;
            Part assemblyPart = theSession.Parts.Open(assemblyFilePath, out loadStatus);

            if (assemblyPart == null)
            {
                MessageBox.Show("Không thể mở file assembly!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Component rootComp = assemblyPart.ComponentAssembly.RootComponent;
            StringBuilder sb = new StringBuilder();

            // Hàm đệ quy liệt kê tên mọi chi tiết
            ListComponentNames(rootComp, sb);

            MessageBox.Show(sb.ToString(), "Danh sách chi tiết Assembly");
        }

        private void ListComponentNames(Component comp, StringBuilder sb)
        {
            foreach (Component child in comp.GetChildren())
            {
                sb.AppendLine(child.Name); // Tên chi tiết
                                           // Nếu muốn thêm thông tin, có thể dùng: child.Prototype.FileName
                ListComponentNames(child, sb); // Đệ quy cho các cấp con
            }
        }



        /******************************************************************/

        /// <summary>
        /// Đổi giá trị 1 parameter (expression) trong 1 component của assembly.
        /// </summary>
        /// <param name="assemblyPartPath">Đường dẫn file assembly (*.prt)</param>
        /// <param name="componentName">Tên component con trong assembly</param>
        /// <param name="parameterName">Tên parameter cần đổi</param>
        /// <param name="newValue">Giá trị mới</param>
        public static void ChangeComponentParameter(string assemblyPartPath, string componentName, string parameterName, double newValue)
        {
            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;
            // Mở assembly nếu chưa mở
            BasePart baseAssembly = theSession.Parts.OpenBaseDisplay(assemblyPartPath, out loadStatus);
            Part asmPart = baseAssembly as Part;
            if (asmPart == null)
                throw new Exception("Không mở được assembly part.");

            // Tìm component con
            ComponentAssembly compAsm = asmPart.ComponentAssembly;
            Component comp = null;
            foreach (Component c in compAsm.RootComponent.GetChildren())
            {
                if (c.Name == componentName)
                {
                    comp = c;
                    break;
                }
            }
            if (comp == null)
                throw new Exception($"Không tìm thấy component tên: {componentName}");

            // Mở part con
            Part workPart = comp.Prototype as Part;
            if (workPart == null)
                throw new Exception($"Không lấy được Part con của component {componentName}");

            // Tìm và cập nhật expression
            Expression targetExp = null;
            foreach (Expression exp in workPart.Expressions)
            {
                if (exp.Name == parameterName)
                {
                    targetExp = exp;
                    break;
                }
            }
            if (targetExp == null)
                throw new Exception($"Không tìm thấy expression '{parameterName}' trong component '{componentName}'");

            // Phân biệt User/Model Parameter dựa trên tên
            bool isUserParameter = !System.Text.RegularExpressions.Regex.IsMatch(targetExp.Name, @"^p\d+$");

            try
            {
                targetExp.Value = newValue;
            }
            catch (Exception ex)
            {
                throw new Exception(
                    isUserParameter ?
                    $"Không thể cập nhật User Parameter '{parameterName}': {ex.Message}" :
                    $"Không thể cập nhật Model Parameter '{parameterName}': {ex.Message}"
                );
            }

            // Cập nhật mô hình và lưu part con
            Session.UndoMarkId markId = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Update Model");
            theSession.UpdateManager.DoUpdate(markId);
            workPart.Save(BasePart.SaveComponents.True, BasePart.CloseAfterSave.False);

            // Có thể cần update lại assembly, tùy nghiệp vụ
            asmPart.Save(BasePart.SaveComponents.True, BasePart.CloseAfterSave.False);

            loadStatus.Dispose();
        }


        public static void ChangeComponentParameters(
            string assemblyPartPath,
            string componentName,
            List<string> parameterNames,
            List<string> parameterValues)
        {
            if (parameterNames.Count != parameterValues.Count)
                throw new ArgumentException("Số lượng tên tham số và giá trị không khớp.");

            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;
            BasePart baseAssembly = theSession.Parts.OpenBaseDisplay(assemblyPartPath, out loadStatus);
            Part asmPart = baseAssembly as Part;
            if (asmPart == null)
                throw new Exception("Không mở được assembly part.");

            ComponentAssembly compAsm = asmPart.ComponentAssembly;
            Component comp = null;
            foreach (Component c in compAsm.RootComponent.GetChildren())
            {
                if (c.Name == componentName)
                {
                    comp = c;
                    break;
                }
            }
            if (comp == null)
                throw new Exception($"Không tìm thấy component tên: {componentName}");

            Part workPart = comp.Prototype as Part;
            if (workPart == null)
                throw new Exception($"Không lấy được Part con của component {componentName}");

            for (int i = 0; i < parameterNames.Count; i++)
            {
                string paraName = parameterNames[i];
                string paraValue = parameterValues[i];

                Expression exp = null;
                foreach (Expression e in workPart.Expressions)
                {
                    if (e.Name == paraName)
                    {
                        exp = e;
                        break;
                    }
                }
                if (exp == null)
                    throw new Exception($"Không tìm thấy expression '{paraName}' trong component '{componentName}'");

                bool isUserParameter = !System.Text.RegularExpressions.Regex.IsMatch(exp.Name, @"^p\d+$");
                try
                {
                    exp.RightHandSide = paraValue;
                }
                catch (Exception ex)
                {
                    throw new Exception(
                        isUserParameter ?
                        $"Không thể cập nhật User Parameter '{paraName}': {ex.Message}" :
                        $"Không thể cập nhật Model Parameter '{paraName}': {ex.Message}"
                    );
                }
            }

            // Update và lưu part con
            Session.UndoMarkId markId = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Update Model");
            theSession.UpdateManager.DoUpdate(markId);
            workPart.Save(BasePart.SaveComponents.True, BasePart.CloseAfterSave.False);

            // Update & lưu assembly nếu cần
            asmPart.Save(BasePart.SaveComponents.True, BasePart.CloseAfterSave.False);

            loadStatus.Dispose();
        }

        //Cách dùng
        //        AssemblyParameterUpdater.ChangeComponentParameter(
        //    @"C:\ASM\topassy.prt",
        //    "COMP1",
        //    "LENGTH",
        //    100.0
        //);

        //Cách dùng
        //var names = new List<string> { "LENGTH", "WIDTH" };
        //        var values = new List<string> { "100", "50" };
        //        AssemblyParameterUpdater.ChangeComponentParameters(
        //    @"C:\ASM\topassy.prt",
        //    "COMP1",
        //    names,
        //    values
        //);

        /**********************************************************/
        public static void ChangeAssemblyParameter(string assemblyPartPath, string paramName, string newValue)
        {
            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;
            Part asmPart = theSession.Parts.Open(assemblyPartPath, out loadStatus);

            Expression found = null;
            foreach (Expression exp in asmPart.Expressions)
            {
                if (exp.Name == paramName)
                {
                    found = exp;
                    break;
                }
            }
            if (found == null)
                throw new Exception($"Không tìm thấy parameter tên {paramName} trong assembly!");

            found.RightHandSide = newValue;

            // Update và lưu
            Session.UndoMarkId markId = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Update Assembly Parameter");
            theSession.UpdateManager.DoUpdate(markId);
            asmPart.Save(BasePart.SaveComponents.True, BasePart.CloseAfterSave.False);

            loadStatus.Dispose();
        }


        public static void ChangeAssemblyParameters(string assemblyPartPath, List<string> paramNames, List<string> paramValues)
        {
            if (paramNames.Count != paramValues.Count)
                throw new ArgumentException("Số lượng tên và giá trị không khớp.");

            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;
            Part asmPart = theSession.Parts.Open(assemblyPartPath, out loadStatus);

            for (int i = 0; i < paramNames.Count; i++)
            {
                string paraName = paramNames[i];
                string paraValue = paramValues[i];
                Expression found = null;

                foreach (Expression exp in asmPart.Expressions)
                {
                    if (exp.Name == paraName)
                    {
                        found = exp;
                        break;
                    }
                }
                if (found == null)
                    throw new Exception($"Không tìm thấy parameter tên {paraName} trong assembly!");

                found.RightHandSide = paraValue;
            }

            // Update và lưu
            Session.UndoMarkId markId = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Update Assembly Parameters");
            theSession.UpdateManager.DoUpdate(markId);
            asmPart.Save(BasePart.SaveComponents.True, BasePart.CloseAfterSave.False);

            loadStatus.Dispose();
        }

        //cách dùng
        //// Đổi 1 tham số
        //ChangeAssemblyParameter(@"C:\ASM\assy1.prt", "LENGTH", "150");

        //// Đổi nhiều tham số
        //var names = new List<string> { "LENGTH", "WIDTH" };
        //var values = new List<string> { "150", "75" };
        //ChangeAssemblyParameters(@"C:\ASM\assy1.prt", names, values);

        //// Đổi User Parameter
        //ChangeAssemblyParameter(@"C:\ASM\assy1.prt", "LENGTH", "150");

        //// Đổi Model Parameter
        //ChangeAssemblyParameter(@"C:\ASM\assy1.prt", "p3", "25");

        //// Đổi nhiều tham số (kết hợp user và model)
        //var names = new List<string> { "LENGTH", "p3" };
        //var values = new List<string> { "200", "30" };
        //ChangeAssemblyParameters(@"C:\ASM\assy1.prt", names, values);

        /******************************************************************************/


        /// <summary>
        /// Suppress một component trong assembly theo tên.
        /// </summary>
        public static void SuppressComponent(string assemblyPartPath, string componentName)
        {
            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;
            Part asmPart = theSession.Parts.Open(assemblyPartPath, out loadStatus);

            ComponentAssembly compAsm = asmPart.ComponentAssembly;
            Component comp = null;
            foreach (Component c in compAsm.RootComponent.GetChildren())
            {
                if (c.Name == componentName)
                {
                    comp = c;
                    break;
                }
            }
            if (comp == null)
                throw new Exception($"Không tìm thấy component tên: {componentName}");

            // Suppress component
            comp.Suppress();

            asmPart.Save(BasePart.SaveComponents.True, BasePart.CloseAfterSave.False);
            loadStatus.Dispose();
        }

        /// <summary>
        /// Unsuppress một component trong assembly theo tên.
        /// </summary>
        public static void UnsuppressComponent(string assemblyPartPath, string componentName)
        {
            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;
            Part asmPart = theSession.Parts.Open(assemblyPartPath, out loadStatus);

            ComponentAssembly compAsm = asmPart.ComponentAssembly;
            Component comp = null;
            foreach (Component c in compAsm.RootComponent.GetChildren())
            {
                if (c.Name == componentName)
                {
                    comp = c;
                    break;
                }
            }
            if (comp == null)
                throw new Exception($"Không tìm thấy component tên: {componentName}");

            // Unsuppress component
            comp.Unsuppress();

            asmPart.Save(BasePart.SaveComponents.True, BasePart.CloseAfterSave.False);
            loadStatus.Dispose();
        }

        /***************************************************************************/
        /// <summary>
        /// Ẩn (invisible) component trong assembly theo tên.
        /// </summary>
        public static void HideComponent(string assemblyPartPath, string componentName)
        {
            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;
            Part asmPart = theSession.Parts.Open(assemblyPartPath, out loadStatus);

            ComponentAssembly compAsm = asmPart.ComponentAssembly;
            Component comp = null;

            foreach (Component c in compAsm.RootComponent.GetChildren())
            {
                if (c.Name == componentName)
                {
                    comp = c;
                    break;
                }
            }
            if (comp == null)
                throw new Exception($"Không tìm thấy component tên: {componentName}");

            // Ẩn component
            comp.Layer = 256;

            asmPart.Save(BasePart.SaveComponents.True, BasePart.CloseAfterSave.False);
            loadStatus.Dispose();
        }

        /// <summary>
        /// Hiện (visible) component trong assembly theo tên.
        /// </summary>
        public static void ShowComponent(string assemblyPartPath, string componentName)
        {
            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;
            Part asmPart = theSession.Parts.Open(assemblyPartPath, out loadStatus);

            ComponentAssembly compAsm = asmPart.ComponentAssembly;
            Component comp = null;

            foreach (Component c in compAsm.RootComponent.GetChildren())
            {
                if (c.Name == componentName)
                {
                    comp = c;
                    break;
                }
            }
            if (comp == null)
                throw new Exception($"Không tìm thấy component tên: {componentName}");

            // Hiện component (Layer mặc định là 1, bạn điều chỉnh theo hệ thống của bạn)
            comp.Layer = 1;

            asmPart.Save(BasePart.SaveComponents.True, BasePart.CloseAfterSave.False);
            loadStatus.Dispose();
        }


        //Cách dùng 
        // Suppress
        //AssemblyComponentUtils.SuppressComponent(@"C:\ASM\assy1.prt", "COMP1");

        //// Unsuppress
        //AssemblyComponentUtils.UnsuppressComponent(@"C:\ASM\assy1.prt", "COMP1");

        //// Hide
        //AssemblyComponentUtils.HideComponent(@"C:\ASM\assy1.prt", "COMP1");

        //// Show
        //AssemblyComponentUtils.ShowComponent(@"C:\ASM\assy1.prt", "COMP1");

        /*****************************************/

        /// <summary>
        /// Suppress hoặc Unsuppress một component trong assembly theo tên.
        /// mode = 1: suppress, mode = 2: unsuppress
        /// </summary>
        public static void SetComponentSuppression(string assemblyPartPath, string componentName, int mode)
        {
            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;
            Part asmPart = theSession.Parts.Open(assemblyPartPath, out loadStatus);

            ComponentAssembly compAsm = asmPart.ComponentAssembly;
            Component comp = null;
            foreach (Component c in compAsm.RootComponent.GetChildren())
            {
                if (c.Name == componentName)
                {
                    comp = c;
                    break;
                }
            }
            if (comp == null)
                throw new Exception($"Không tìm thấy component tên: {componentName}");

            if (mode == 1)
                comp.Suppress();
            else if (mode == 2)
                comp.Unsuppress();
            else
                throw new ArgumentException("mode chỉ nhận giá trị 1 (suppress) hoặc 2 (unsuppress)");

            asmPart.Save(BasePart.SaveComponents.True, BasePart.CloseAfterSave.False);
            loadStatus.Dispose();
        }


        /// <summary>
        /// Ẩn hoặc hiện một component trong assembly theo tên.
        /// mode = 1: ẩn (invisible), mode = 2: hiện (visible)
        /// </summary>
        public static void SetComponentVisibility(string assemblyPartPath, string componentName, int mode)
        {
            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;
            Part asmPart = theSession.Parts.Open(assemblyPartPath, out loadStatus);

            ComponentAssembly compAsm = asmPart.ComponentAssembly;
            Component comp = null;
            foreach (Component c in compAsm.RootComponent.GetChildren())
            {
                if (c.Name == componentName)
                {
                    comp = c;
                    break;
                }
            }
            if (comp == null)
                throw new Exception($"Không tìm thấy component tên: {componentName}");

            if (mode == 1)
                comp.Layer = 256; // Ẩn
            else if (mode == 2)
                comp.Layer = 1;   // Hiện (hoặc layer bạn muốn)
            else
                throw new ArgumentException("mode chỉ nhận giá trị 1 (ẩn) hoặc 2 (hiện)");

            asmPart.Save(BasePart.SaveComponents.True, BasePart.CloseAfterSave.False);
            loadStatus.Dispose();
        }

        //Cách dùng
        //// Suppress
        //SetComponentSuppression(@"C:\ASM\assy1.prt", "COMP1", 1);
        //// Unsuppress
        //SetComponentSuppression(@"C:\ASM\assy1.prt", "COMP1", 2);

        //// Ẩn component
        //SetComponentVisibility(@"C:\ASM\assy1.prt", "COMP1", 1);
        //// Hiện component
        //SetComponentVisibility(@"C:\ASM\assy1.prt", "COMP1", 2);


        /******************************************************/

        /// <summary>
        /// Tự động cập nhật assembly NX khi có bất kỳ thay đổi thành phần (component, parameter, constraint...).
        /// </summary>
        /// <param name="assemblyPartPath">Đường dẫn tới file assembly (*.prt)</param>
        public static void AutoUpdateAssembly(string assemblyPartPath)
        {
            Session theSession = Session.GetSession();
            PartLoadStatus loadStatus;
            Part asmPart = theSession.Parts.Open(assemblyPartPath, out loadStatus);

            // Đặt undo mark để update
            Session.UndoMarkId markId = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Auto Update Assembly");
            theSession.UpdateManager.DoUpdate(markId);

            // Lưu lại trạng thái mới của assembly
            asmPart.Save(BasePart.SaveComponents.True, BasePart.CloseAfterSave.False);

            loadStatus.Dispose();
        }
        //Cách dùng
        //AssemblyUpdateHelper.AutoUpdateAssembly(@"C:\ASM\assy1.prt");

    }
}

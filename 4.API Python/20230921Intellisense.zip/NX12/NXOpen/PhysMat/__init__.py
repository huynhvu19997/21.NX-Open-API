from ...NXOpen import *
from ..PhysMat import *

import typing
import enum

class PhysicalMaterialListBuilder(Builder):
    def __init__(self) -> None: ...


class PhysicalMaterialLibMgrBuilder(Builder):
    def __init__(self) -> None: ...


class PhysicalMaterialAssignBuilder(Builder):
    def __init__(self) -> None: ...



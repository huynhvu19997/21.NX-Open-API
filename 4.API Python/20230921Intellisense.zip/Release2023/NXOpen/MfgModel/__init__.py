from ...NXOpen import *
from ..MfgModel import *

import typing
import enum

class NamespaceDoc(System.Object):
    def __init__(self) -> None: ...



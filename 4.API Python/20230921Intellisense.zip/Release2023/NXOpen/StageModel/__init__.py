from ...NXOpen import *
from ..StageModel import *

import typing
import enum

class NamespaceDoc(System.Object):
    def __init__(self) -> None: ...



from ...NXOpen import *
from ..LineDesigner import *

import typing
import enum

class NamespaceDoc(System.Object):
    def __init__(self) -> None: ...



﻿namespace TheScriptingEngineerSection11
{
    using System;
    using System.IO; // for path operations
    using System.Collections.Generic; // for lists
    using NXOpen; // so we can use NXOpen functionality
    using NXOpen.CAE; // so we don't need to start everything with NXOpen.CAE
    using NXOpenUI;
    using NXOpen.UF;
    using NXOpen.Utilities;
    using NXOpen.VectorArithmetic;
    
    public class Program
    {
        // global variables used throughout
        public static Session theSession = Session.GetSession();
        public static ListingWindow theLW = theSession.ListingWindow;
        public static BasePart basePart = theSession.Parts.BaseWork;

        public static void Main(string[] args)
        {
            theLW.Open();
            theLW.WriteFullline("Starting Main() in " + theSession.ExecutingJournal);

            FemPart femPart = null;
            if (basePart as SimPart !=null)
            {
                // we started from a sim file
                SimPart simPart = (SimPart)basePart;
                CaePart caePart = simPart.FemPart;  // ComponentAssembly.RootComponent.GetChildren()[0].Prototype.OwningPart;
                if (caePart as FemPart == null)
                {
                    // simfile is linked to .afem file
                    theLW.WriteFullline("Create groups from CAD does not support .afem files yet.");
                    return;
                }

                femPart = (FemPart)caePart;
            }
            else if (basePart as AssyFemPart != null)
            {
                // we startef from a .afem file
                theLW.WriteFullline("Create groups from CAD does not support .afem files yet.");
                return;
            }
            else if (basePart as FemPart !=null)
            {
                // we started from a fem file
                femPart = (FemPart)basePart;
            }
            else
            {
                // not started from a cae part
                theLW.WriteFullline("Create groups does not work on non-cae parts");
                return;
            }

            AddRelatedNodesAndElements(femPart);
        }

        public static void AddRelatedNodesAndElements(CaePart caePart)
        {
            CaeGroup[] caeGroups = caePart.CaeGroups.ToArray();
            foreach (CaeGroup item in caeGroups)
            {
                theLW.WriteFullline("Processing group " + item.Name);
                List<CAEBody> seedsBody = new List<CAEBody>();
                List<CAEFace> seedsFace = new List<CAEFace>();

                foreach (TaggedObject taggedObject in item.GetEntities())
                {
                    if (taggedObject is CAEBody)
                    {
                        seedsBody.Add((CAEBody)taggedObject);
                    }
                    else if (taggedObject is CAEFace)
                    {
                        seedsFace.Add((CAEFace)taggedObject);
                    }
                }

                SmartSelectionManager smartSelectionManager = caePart.SmartSelectionMgr;

                RelatedElemMethod relatedElemMethodBody = smartSelectionManager.CreateRelatedElemMethod(seedsBody.ToArray(), false);
                RelatedNodeMethod relatedNodeMethodBody = smartSelectionManager.CreateRelatedNodeMethod(seedsBody.ToArray(), false);
                // comment previous line and uncomment next line for NX version 2007 (release 2022.1) and later
                // RelatedNodeMethod relatedNodeMethodBody = smartSelectionManager.CreateNewRelatedNodeMethodFromBodies(seedsBody.ToArray(), false, false);
                
                item.AddEntities(relatedElemMethodBody.GetElements());
                item.AddEntities(relatedNodeMethodBody.GetNodes());

                RelatedElemMethod relatedElemMethodFace = smartSelectionManager.CreateRelatedElemMethod(seedsFace.ToArray(), false);
                RelatedNodeMethod relatedNodeMethodFace = smartSelectionManager.CreateRelatedNodeMethod(seedsFace.ToArray(), false);
                // comment previous line and uncomment next line for NX version 2007 (release 2022.1) and later
                // RelatedNodeMethod relatedNodeMethodFace = smartSelectionManager.CreateNewRelatedNodeMethodFromFaces(seedsFace.ToArray(), false, false);

                item.AddEntities(relatedElemMethodFace.GetElements());
                item.AddEntities(relatedNodeMethodFace.GetNodes());
            }
        }
    }
}
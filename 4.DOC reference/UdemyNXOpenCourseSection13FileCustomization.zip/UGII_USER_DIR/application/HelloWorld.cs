﻿namespace TheScriptingEngineer
{
    using System;
    using NXOpen;
    using NXOpen.CAE;
    using NXOpen.Utilities;
    using NXOpen.UF;
    using NXOpenUI;

    public class HelloWorld
    {
        static NXOpen.Session theSession = NXOpen.Session.GetSession();
        static ListingWindow theLW = theSession.ListingWindow;
        static BasePart basePart = theSession.Parts.BaseWork;

        public static void Main(string[] args)
        {
            theLW.Open();
            theLW.WriteFullline("Starting Main() in " + theSession.ExecutingJournal);
            
            theLW.WriteFullline("The following " + args.Length.ToString() + " have been passed to Main():");
            foreach (string item in args)
            {
                theLW.WriteFullline("\t" + item);
            }

        }
    }    
}
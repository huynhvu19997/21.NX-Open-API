﻿namespace TheScriptingEngineerSection10
{
    using System;
    using System.IO; // for path operations
    using System.Collections.Generic; // for lists
    using NXOpen; // so we can use NXOpen functionality
    using NXOpen.CAE; // so we don't need to start everything with NXOpen.CAE
    using NXOpenUI;
    using NXOpen.UF;
    using NXOpen.Utilities;
    
    public class Program
    {
        // global variables used throughout
        public static Session theSession = Session.GetSession();
        public static ListingWindow theLW = theSession.ListingWindow;
        public static BasePart basePart = theSession.Parts.BaseWork;

        public static void Main(string[] args)
        {
            theLW.Open();
            theLW.WriteFullline("Starting Main() in " + theSession.ExecutingJournal);

            BasePart[] allPartsInSession = theSession.Parts.ToArray();
            theLW.WriteFullline("The following parts are loaded in the session: ");
            foreach (BasePart item in allPartsInSession)
            {
                theLW.WriteFullline(string.Format("\t{0, -50}{1, -128}", item.Name, item.FullPath));
            }
            theLW.WriteFullline("");

            BasePart baseDisplayPart = theSession.Parts.BaseDisplay;
            theLW.WriteFullline("The current workpart is: " + basePart.Name + " located in " + basePart.FullPath);
            theLW.WriteFullline("The current displaypart is: " + baseDisplayPart.Name + " located in " + baseDisplayPart.FullPath);
            theLW.WriteFullline("");

            if (basePart as SimPart != null)
            {
                theLW.WriteFullline("Starting from a .sim part.");
                SimPart simPart = (SimPart)basePart;
                PrintPartTree(simPart);

                theLW.WriteFullline("----------------------------------------------------------------------------");
                theLW.WriteFullline("------------------------------ Component tree ------------------------------");
                theLW.WriteFullline("----------------------------------------------------------------------------");
                PrintComponentTree(simPart.ComponentAssembly.RootComponent);
                
                theLW.WriteFullline("------------------------------------------------------------------------------");
                theLW.WriteFullline("--------------------------- FEModelOccurrence tree ---------------------------");
                theLW.WriteFullline("------------------------------------------------------------------------------");
                PrintOccurrenceTree(simPart.Simulation.Femodel);
            }
            else if (basePart as AssyFemPart != null)
            {
                theLW.WriteFullline("Starting from a .afem part.");
                AssyFemPart assyFemPart = (AssyFemPart)basePart;

                PrintPartTree(assyFemPart);

                theLW.WriteFullline("----------------------------------------------------------------------------");
                theLW.WriteFullline("------------------------------ Component tree ------------------------------");
                theLW.WriteFullline("----------------------------------------------------------------------------");
                PrintComponentTree(assyFemPart.ComponentAssembly.RootComponent);

                theLW.WriteFullline("------------------------------------------------------------------------------");
                theLW.WriteFullline("--------------------------- FEModelOccurrence tree ---------------------------");
                theLW.WriteFullline("------------------------------------------------------------------------------");
                // Contrary to SimPart, there is no top level FEModelOccurrence.
                // In order to get the FEModelOccurences we need to get the BaseFEModel and cast it to a AssyFEModel.
                // We know the casting will work as we work with an AssyFemPart.
                // From the AssyFEModel we can get the FEModelOccurrences by calling GetChildren()
                AssyFEModel assyFEModel =  (AssyFEModel)assyFemPart.BaseFEModel;
                FEModelOccurrence[] children = assyFEModel.GetChildren();
                for (int i = 0; i < children.Length; i++)
                {
                    PrintOccurrenceTree(children[i]);
                }
            }
            else if (basePart as FemPart != null)
            {
                theLW.WriteFullline("Starting from a .fem part.");
                FemPart femPart = (FemPart)basePart;
                PrintPartTree(femPart);
            }
            else if (basePart as Part != null)
            {
                PrintPartTree(basePart);
                PrintComponentTree(basePart.ComponentAssembly.RootComponent);
                return;
            }
            else
            {
                theLW.WriteFullline("Not started from a cae part. Exiting");
                return;
            }
        }

        /// <summary>
        /// This method prints a tree of the FeModelOccurrences to the SimCenter listing window. Only works for sim and afem parts.
        /// </summary>
        /// <param name="fEModelOccurrence">The top level FEModelOccurrence to print the tree for.</param>
        public static void PrintOccurrenceTree(FEModelOccurrence fEModelOccurrence, int requestedLevel = 0)
        {
            int level = requestedLevel;
            // we print the journal identifier for the component so we can see the difference (eg each FeModelOccurrence has a one to one link with the component)
            theLW.WriteFullline(Indentation(level) + "| " + fEModelOccurrence.JournalIdentifier + " --> component --> " + 
                fEModelOccurrence.OwningComponent.JournalIdentifier + " is a component(instance) of " + 
                fEModelOccurrence.OwningComponent.Prototype.OwningPart.Name + " located in " + 
                fEModelOccurrence.OwningPart.Name);
            FEModelOccurrence[] children = fEModelOccurrence.GetChildren();
            for (int i = 0; i < children.Length ; i++)
            {
                PrintOccurrenceTree(children[i], level + 1);
            }
        }

        /// <summary>
        /// This method prints a tree of the components to the SimCenter listing window.
        /// </summary>
        /// <param name="component">The top level component to print the tree for.</param>
        public static void PrintComponentTree(NXOpen.Assemblies.Component component, int requestedLevel = 0)
        {
            int level = requestedLevel;
            theLW.WriteFullline(Indentation(level) + "| " + component.JournalIdentifier + " is a compont(instance) of " + 
                component.Prototype.OwningPart.Name + " located in " + component.OwningPart.Name);
            NXOpen.Assemblies.Component[] children = component.GetChildren();
            for (int i = 0; i < children.Length ; i++)
            {
                PrintComponentTree(children[i], level + 1);
            }
        }

        /// <summary>
        /// This method prints a tree of the parts to the SimCenter listing window. Also supports non cae parts.
        /// </summary>
        /// <param name="basePart">The top level part to print the tree for. Can be any part. </param>
        public static void PrintPartTree(BasePart basePart, int requestedLevel = 0)
        {
            int level = requestedLevel;
            if (basePart as SimPart != null)
            {
                SimPart simPart = (SimPart)basePart;
                theLW.WriteFullline(simPart.Name);

                // PrintPartTree(simPart.ComponentAssembly.RootComponent.GetChildren()[0].Prototype.OwningPart);
                PrintPartTree(simPart.FemPart);
            }
            else if (basePart as AssyFemPart != null)
            {
                AssyFemPart assyFemPart = (AssyFemPart)basePart;
                theLW.WriteFullline(Indentation(level) + "| " + assyFemPart.Name + " located in " + 
                    assyFemPart.FullPath + " linked to part " + assyFemPart.FullPathForAssociatedCadPart);
                NXOpen.Assemblies.Component[] children = assyFemPart.ComponentAssembly.RootComponent.GetChildren();
                for (int i = 0; i < children.Length; i++)
                {
                    PrintPartTree(children[i].Prototype.OwningPart, level + 1);
                }
            }
            else if (basePart as FemPart != null)
            {
                FemPart femPart = (FemPart)basePart;
                // try catch since calling femPart.FullPathForAssociatedCadPart on a part which has no cad part results in an error
                try
                {
                    // femPart.MasterCadPart returns the actual part, but is null if the part is not loaded.
                    theLW.WriteFullline(Indentation(level) + "| " + femPart.Name + " which is linked to part " + femPart.FullPathForAssociatedCadPart);
                }
                catch (System.Exception)
                {
                    // femPart has no associated cad part
                    theLW.WriteFullline(Indentation(level) + "| " + femPart.Name + " not linked to a part.");
                }
            }
            else
            {
                theLW.WriteFullline(Indentation(level) + "| " + basePart.Name + " located in " + basePart.FullPath);
                // check if part contains other parts. if not, GetChildren give object not set to reference error.
                if (basePart.ComponentAssembly.RootComponent != null)
                {
                    // part contains other parts
                    NXOpen.Assemblies.Component[] children = basePart.ComponentAssembly.RootComponent.GetChildren();
                    for (int i = 0; i < children.Length; i++)
                    {
                        PrintPartTree(children[i].Prototype.OwningPart, level + 1);
                    }
                }

            }
        }

        /// <summary>
        /// Helper method for adding indentation to the listing window.
        /// </summary>
        /// <param name="level">The amount of tabs to return</param>
        /// <returns>A string containing level number of tabs.</returns>
        public static string Indentation(int level)
        {
            string indentation = "";
            for (int i = 0; i < level + 1; i++)
            {
                indentation = indentation + "\t";
            }

            return indentation;
        }
    }
}